module.exports = {
  apps: [
    {
      name: 'frontend',
      script: 'npm',
      args: 'start',
      cwd: '/root/cryp/front',
      interpreter: 'none',
      env: {
        NODE_ENV: 'development',
      },
    },
  ],
};
