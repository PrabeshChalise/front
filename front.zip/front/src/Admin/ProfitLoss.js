import React from "react";

const ProfitLoss = () => {
  return <div>ProfitLoss</div>;
};

export default ProfitLoss;
